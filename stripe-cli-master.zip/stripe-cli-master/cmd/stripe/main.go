package main

import "github.com/stripe/stripe-cli/pkg/cmd"

func main() {
	cmd.Execute()
}
